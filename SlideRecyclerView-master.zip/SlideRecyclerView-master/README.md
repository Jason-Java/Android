# SlideRecyclerView
实现RecyclerView侧滑菜单栏，交互流畅<br/>
博文[《Android RecyclerView —— 实现侧滑菜单》](https://blog.csdn.net/qq_40861368/article/details/88845233)的源码
