package com.xw.sample.slidinguppanellayout;

import android.app.Application;
import android.support.v7.app.AppCompatDelegate;

/**
 * <p>
 * Created by woxingxiao on 2017-07-14.
 */

public class SPLApplication extends Application {

    static {
        AppCompatDelegate.setCompatVectorFromResourcesEnabled(true);
    }

}
