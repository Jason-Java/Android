package com.guanaj.easyswipemenulibrary;

/**
 * Created by guanaj on 2017/6/6.
 */

public enum State {
    LEFTOPEN,
    RIGHTOPEN,
    CLOSE,
}
