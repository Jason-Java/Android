package com.hanks.htextview.base;

/**
 * AnimationListener
 */

public interface AnimationListener {
    void onAnimationEnd(HTextView hTextView);
}
