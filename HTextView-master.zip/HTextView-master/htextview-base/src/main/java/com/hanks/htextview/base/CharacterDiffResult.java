package com.hanks.htextview.base;
/**
 * Created by hanks on 15-12-14.
 */
public class CharacterDiffResult {
    public char c;
    public int  fromIndex;
    public int  moveIndex;
}
