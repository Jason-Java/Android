package iammert.com.library;

/**
 * Created by mertsimsek on 26/01/17.
 */

public enum Status {
    IDLE, LOADING, ERROR, COMPLETE
}
