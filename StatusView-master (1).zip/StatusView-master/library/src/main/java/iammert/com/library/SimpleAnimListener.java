package iammert.com.library;

import android.view.animation.Animation;

/**
 * Created by mertsimsek on 26/01/17.
 */

public abstract class SimpleAnimListener implements Animation.AnimationListener {

    @Override
    public void onAnimationRepeat(Animation animation) {

    }

    @Override
    public void onAnimationStart(Animation animation) {

    }
}
